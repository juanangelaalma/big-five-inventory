<a class="text-md font-normal text-dark-grey-700 hover:text-dark-grey-900" href="/">Beranda</a>
<a class="text-md font-normal text-dark-grey-700 hover:text-dark-grey-900" href="{{ route('instruments.answer') }}">Kuesioner</a>
<a class="text-md font-normal text-dark-grey-700 hover:text-dark-grey-900" href="{{ route('answers.result') }}">Hasil Analisis</a>
