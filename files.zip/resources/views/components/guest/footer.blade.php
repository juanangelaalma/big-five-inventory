<footer class="max-w-6xl mx-auto py-10">
    <div class="flex justify-center items-center space-x-2">
        <x-brand />
        <p>Menara Cakrawala 12th Floor Unit 5A, Jl. MH. Thamrin, Jakarta Pusat 10340</p>
    </div>
</footer>
