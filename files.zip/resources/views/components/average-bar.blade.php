<div id="result-bar" datasets="{{ $data }}" labels="{{ $labels }}" class="min-w-0 p-4 bg-white rounded-lg shadow-xs dark:bg-gray-800">
    <h4 class="mb-4 font-semibold text-gray-800 dark:text-gray-300">
        Rata-rata hasil prediksi
    </h4>
    <canvas id="barsResult"></canvas>
</div>
