<div id="age-bar" datasets="{{ $agesTotal }}" labels="{{ $ageLabels }}" class="min-w-0 p-4 bg-white rounded-lg shadow-xs dark:bg-gray-800">
    <h4 class="mb-4 font-semibold text-gray-800 dark:text-gray-300">
        Umur Responden
    </h4>
    <canvas id="barsAge"></canvas>
</div>
