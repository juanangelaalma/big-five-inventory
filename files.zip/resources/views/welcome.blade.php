<x-guest-layout title="Beranda">
    <x-guest.header />
    <x-guest.introduction />
    <x-guest.footer />
</x-guest-layout>
