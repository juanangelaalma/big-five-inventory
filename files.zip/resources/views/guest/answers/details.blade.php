<x-app-layout class="bg-white">
    <div class="px-24">
        <x-personality-test-result :user=$user :answered_at=$answered_at :results=$results />
    </div>
</x-app-layout>
