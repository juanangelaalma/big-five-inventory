<x-admin-layout pageTitle="Dashboard">
  Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis voluptates aliquam, odit suscipit porro eum accusamus omnis illum expedita aliquid optio veniam ad autem ullam repudiandae dolorum cum laudantium hic.
</x-admin-layout>